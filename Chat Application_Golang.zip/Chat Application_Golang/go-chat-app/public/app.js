var socket = null; // Initialize socket to null

// Show Registration Form
function showRegister() {
    document.querySelector('.login-form').classList.add('d-none');
    document.querySelector('.registration-form').classList.remove('d-none');
}

// Show Login Form
function showLogin() {
    document.querySelector('.registration-form').classList.add('d-none');
    document.querySelector('.login-form').classList.remove('d-none');
}

// Register a New User
function register() {
    var username = document.getElementById('reg-username').value;
    var password = document.getElementById('reg-password').value;

    if (username && password) {
        // Send registration data to the server
        fetch('/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username: username, password: password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Registration successful! Please log in.');
                showLogin();
            } else {
                alert('Registration failed: ' + data.message);
            }
        })
        .catch(err => console.error('Error:', err)); // Add error handling
    } else {
        alert("Please enter a username and password!");
    }
}

// Login a User
function login() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (username && password) {
        // Send login data to the server
        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username: username, password: password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelector('.login-form').classList.add('d-none');
                document.querySelector('.chat-container').classList.remove('d-none');
                startWebSocket(username); // Pass the username to WebSocket
            } else {
                alert('Login failed: ' + data.message);
            }
        })
        .catch(err => console.error('Error:', err)); // Add error handling
    } else {
        alert("Please enter username and password!");
    }
}

// Initialize WebSocket connection
function startWebSocket(username) {
    if (!socket || socket.readyState === WebSocket.CLOSED) {
        socket = new WebSocket('ws://' + window.location.host + '/ws');
    }

    socket.onopen = function() {
        console.log('WebSocket connection established');
    };

    socket.onmessage = function (event) {
        var message = JSON.parse(event.data);
        var chatBox = document.getElementById('chat-box');
        var bubbleClass = (message.username === username) ? 'chat-bubble user' : 'chat-bubble other';
        
        var bubble = document.createElement('div');
        bubble.className = bubbleClass;
        bubble.innerHTML = '<strong>' + message.username + ':</strong> ' + message.message;
        chatBox.appendChild(bubble);
        chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll to the bottom
    };

    socket.onerror = function (error) {
        console.error('WebSocket Error:', error);
    };

    socket.onclose = function() {
        console.log('WebSocket connection closed');
    };
}

// Send a message to the WebSocket server
function sendMessage() {
    if (socket && socket.readyState === WebSocket.OPEN) {
        var message = {
            username: document.getElementById('username').value, // Use the logged-in user's username
            message: document.getElementById('message').value
        };
        socket.send(JSON.stringify(message));
        document.getElementById('message').value = ''; // Clear the input field after sending
    } else {
        alert("WebSocket is not connected.");
    }
}

// Ensure WebSocket closes properly when the user leaves the page
window.onbeforeunload = function () {
    if (socket) {
        socket.close();
    }
};
